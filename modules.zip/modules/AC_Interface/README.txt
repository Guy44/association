2010 Annual Checklist Interface
by ETI BioInformatics

RELEASE INFORMATION
====================
Annual Checklist Interface v1.5 r778
Released on Wed Mar  3 12:51:15 2010

ABOUT THIS SOFTWARE
====================
This web application provides an interface to the 2010 Annual Checklist 
database. It is written in PHP 5, based on the following third-party open source 
software: Zend Framework and Dojo Toolkit.

FEATURES
=========
Functional:    
  * Search for common names and scientific names
  * Search for distributions
  * Export search results
  * Browse by classification
  * Browse taxonomic tree
  * Species and common names details
  * References details
  * Source databases details

Non-functional:
  * Cache system
  * Error logging system

LIMITATIONS
============
* UTF-8 encoding not yet supported

INSTALLATION
=============
Please see the INSTALL.txt file for installation instructions.

LICENSING
==========
This software makes use of third-party open source libraries. You can find a 
copy of their license in:
  * application/library/Zend/LICENSE.txt, Zend Framework
  * public/scripts/library/dojo/LICENSE.txt, Dojo Toolkit