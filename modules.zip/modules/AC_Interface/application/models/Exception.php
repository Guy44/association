<?php
/**
 * Annual Checklist Interface
 *
 * Class ACI_Model_Exception
 *
 * @category    ACI
 * @package     application
 * @subpackage  models
 *
 */
class ACI_Model_Exception extends Zend_Exception {}